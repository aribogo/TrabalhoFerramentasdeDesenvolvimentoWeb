import { Component} from '@angular/core';
import {Aluno} from './Aluno';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  /**
   * Título
   */
  title = 'uninterWeb';

  /**
   * Array com as infromações que serão apresentadas na tabela
   */
  alunos: Aluno[] = [
    {nome:"Ariadne Isabel Machado Bogo", ru:2587884, nomeCurso:"Análise e Desenvolvimento de Sistemas",dataAniversario:"15/03/1998"},
    {nome:"teste 1", ru:1233454, nomeCurso:"Ciência de Dados", dataAniversario:"01/03/1998"},
    {nome:"teste 2", ru:1233457, nomeCurso:"Engenharia da Computação",dataAniversario:"16/03/1998"},
    {nome:"teste 3", ru:1233453, nomeCurso:"Marketing",dataAniversario:"22/03/1998"},
    {nome:"teste 4", ru:1237453, nomeCurso:"Jornalismo",dataAniversario:"20/03/1998"}

];
  
}
