
/**
 * Classe de base para gerar o array de informações sobre os alunos
 */
export class  Aluno {
    nome:String;
    ru:Number;
    nomeCurso: string;
    dataAniversario: string;
}




